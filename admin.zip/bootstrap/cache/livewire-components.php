<?php return array (
  'products.create' => 'App\\Http\\Livewire\\Products\\Create',
  'products.edit' => 'App\\Http\\Livewire\\Products\\Edit',
);