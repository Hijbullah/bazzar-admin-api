<tr>
    <td class="border-t px-6 py-8 text-center" colspan="2">No Category found. Add some first</td>
</tr><?php /**PATH C:\www\laravel_nuxt\bazar\admin\resources\views/pages/categories/children-empty.blade.php ENDPATH**/ ?>