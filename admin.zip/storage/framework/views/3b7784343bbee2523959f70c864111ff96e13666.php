
<option value="<?php echo e($category->id); ?>">
    <?php for($i = 0; $i < $category->depth; $i++): ?>
        <?php echo e('-'); ?> 
    <?php endfor; ?>

    <?php echo e($category->name); ?>

</option>

<?php if($category->children): ?>
    <?php echo $__env->renderEach('pages.products.category-child', $category->children, 'category'); ?>
<?php endif; ?>
<?php /**PATH C:\www\laravel_nuxt\bazar\admin\resources\views/pages/products/category-child.blade.php ENDPATH**/ ?>