<?php echo e($slot); ?>

<?php /**PATH C:\www\laravel_nuxt\bazar\admin\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>